package org.example.web.dto;


import lombok.Data;

@Data
public class ApplicationForm {
    private Integer applicationId;
    private Integer applicationStatus;
}
