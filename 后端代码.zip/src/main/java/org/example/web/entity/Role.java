package org.example.web.entity;

public enum Role {
    ADMIN,
    USER
}
